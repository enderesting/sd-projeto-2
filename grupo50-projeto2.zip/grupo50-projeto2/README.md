# sd-projeto
Grupo 50 <br>
Filipe Costa - 55549 <br>
Yichen Cao - 58165 <br>
Emily Sá - 58200 <br>
Github repo: https://github.com/enderesting/sd-projeto-2

## Build
A compilação deste projeto é realizada correndo os comandos:

```bash
make
```

A makefile também admite uma receita para a remoção dos ficheiros compilados através de `make clean`

